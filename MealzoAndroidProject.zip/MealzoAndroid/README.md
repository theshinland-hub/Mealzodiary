# Mealzo Diary — Android project

This project wraps your uploaded Mealzo internship diary in an Android WebView and uses your Mealzo Mmm! image as the app launcher icon. Diary records are stored locally on the device.

## Build the APK
1. Install Android Studio with Android SDK Platform 35.
2. Open this `MealzoAndroid` folder in Android Studio.
3. Wait for Gradle sync.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

To create a signed release APK, use **Build → Generate Signed App Bundle or APK**.

## Details
- App name: Mealzo Diary
- Package ID: `com.mealzo.diary`
- Minimum Android: Android 6.0 (API 23)
- Main diary works offline; Google Fonts references were removed.
- This environment does not have Android SDK/Gradle installed, so it could not compile a finished APK here. This is the ready-to-build Android Studio project.
